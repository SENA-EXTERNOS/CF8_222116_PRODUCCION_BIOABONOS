function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6APov5E5Rj9":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

