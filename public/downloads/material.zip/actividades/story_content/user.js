function ExecuteScript(strId)
{
  switch (strId)
  {
      case "637Yz3PR820":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

